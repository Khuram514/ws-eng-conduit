export * from './lib/profile.component';
export * from './lib/profile.routes';
