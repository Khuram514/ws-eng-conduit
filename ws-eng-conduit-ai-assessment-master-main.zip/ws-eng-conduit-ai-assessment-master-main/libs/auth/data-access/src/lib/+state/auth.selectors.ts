import { authFeature } from './auth.reducer';

export const { selectAuthState, selectLoggedIn, selectStatus, selectUser } = authFeature;
