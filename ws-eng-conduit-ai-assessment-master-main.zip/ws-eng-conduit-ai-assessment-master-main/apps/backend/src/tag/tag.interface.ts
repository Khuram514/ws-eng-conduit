export interface ITagsRO {
  tags: string[];
}
